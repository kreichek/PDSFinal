1. Kevin Reichek (kreichek), William Willsey (wwillsey), Bora Sebuktekin (bsebukte)
2. Simply run each code block assuming you have all libraries used installed. Note that you should run the appendix at the bottom of the notebook first as that has many utility functions that are used throughout the notebook.
3. http://nbviewer.jupyter.org/github/kreichek/PDSFinal/blob/master/True%20Rating%20of%20Yelp%20Restaurants.ipynb
4. Download our dataset and map HTML file from Dropbox: https://www.dropbox.com/sh/yok40a31ruq8iur/AADsiWtZrHznvyA3odX14AkFa?dl=0. Place the Extras folder in the same directory as the notebook file.
5. We did not use any external sources. Our data comes from web scraping from the Yelp website along with using the Yelp API.

